import sys
import os
import shutil
from pathlib import Path
import fitz  # PyMuPDF

# ---------------------------------------------------
# FIXED BASE DIRECTORY (YOU SET ONLY THIS)
# ---------------------------------------------------
MYAPP_DIR = r"C:\Users\Udhaya\Downloads\PDFProcess"

# ---------------------------------------------------
# Create folder structure
# ---------------------------------------------------
UPLOADS_DIR = os.path.join(MYAPP_DIR, "uploads")
INPROGRESS_DIR = os.path.join(UPLOADS_DIR, "inprogress")
PROCESSED_DIR = os.path.join(UPLOADS_DIR, "processed")
OUT_DIR = os.path.join(UPLOADS_DIR, "out")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(INPROGRESS_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------------------------------
# Sys argv → only PDF file paths
# ---------------------------------------------------
PDF_FILES = sys.argv[1:]   # user gives file paths

if not PDF_FILES:
    print("❌ No files received from sys.argv")
    sys.exit(0)

print(f"Processing {len(PDF_FILES)} file(s):")

# ---------------------------------------------------
# PROCESS EACH PDF
# ---------------------------------------------------
for file_path in PDF_FILES:
    pdf_path = Path(file_path)

    if not pdf_path.exists() or pdf_path.suffix.lower() != ".pdf":
        print(f"❌ Skipping invalid file: {pdf_path}")
        continue

    filename = pdf_path.name

    # 1. Move PDF → inprogress
    inprogress_file = Path(INPROGRESS_DIR) / filename
    shutil.copy2(pdf_path, inprogress_file)  # copy safe

    print(f"\n➡ Inprogress: {filename}")

    # 2. Extract text
    text = ""
    pdf = fitz.open(inprogress_file)
    for page in pdf:
        text += page.get_text()
    pdf.close()

    # 3. Save TXT in "out" folder
    txt_name = filename.replace(".pdf", ".txt")
    txt_path = Path(OUT_DIR) / txt_name

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(text)

    print(f"✔ Saved TXT: {txt_name}")

    # 4. Move PDF → processed
    processed_file = Path(PROCESSED_DIR) / filename
    shutil.move(inprogress_file, processed_file)

    print(f"✔ PDF Moved to processed: {filename}")

print("\n🎉 Done! All files processed.")
