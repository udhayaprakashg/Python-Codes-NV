import fitz  # PyMuPDF
import os
import shutil
from datetime import datetime

# ------------------------------------
# CHANGE ONLY THIS PATH
MYAPP_DIR = r"C:\Users\Udhaya\Downloads\PDFProcess"
# ------------------------------------

UPLOADS_DIR = os.path.join(MYAPP_DIR, "uploads")
OUTPUT_TEXT_FILE = os.path.join(UPLOADS_DIR, "extracted.txt")

os.makedirs(UPLOADS_DIR, exist_ok=True)

# Get only PDF files
pdf_files = [f for f in os.listdir(UPLOADS_DIR) if f.lower().endswith(".pdf")]

if not pdf_files:
    print("No PDF found in uploads folder.")
    exit()

# Process only ONE PDF (first file)
filename = pdf_files[0]
pdf_path = os.path.join(UPLOADS_DIR, filename)

print(f"Processing single PDF: {filename}")

# Extract text
pdf = fitz.open(pdf_path)
text = ""
for page in pdf:
    text += page.get_text()
pdf.close()

# Append with timestamp
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

with open(OUTPUT_TEXT_FILE, "a", encoding="utf-8") as f:
    f.write(f"\n\n--- Extracted From: {filename} at {timestamp} ---\n")
    f.write(text)

# Rename the PDF after processing (e.g., add "_done")
new_name = filename.replace(".pdf", "_done.pdf")
new_path = os.path.join(UPLOADS_DIR, new_name)

shutil.move(pdf_path, new_path)

print(f"Done! Extracted & renamed to: {new_name}")
