import os
from datetime import datetime

# Set your output folder path here
OUTPUT_FOLDER = r"C:\Users\Udhaya\Downloads\django_file_scheduler\Testing"

# Make sure the folder exists
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Generate filename using current date & time
filename = datetime.now().strftime("file_%Y%m%d_%H%M%S.txt")

# Full path
full_path = os.path.join(OUTPUT_FOLDER, filename)

# Write some content
with open(full_path, "w") as f:
    f.write("This file was created automatically.\n")

print(f"Created: {full_path}")
