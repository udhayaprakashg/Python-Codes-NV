import fitz  # PyMuPDF
import os
import shutil

# ------------------------------------
# CHANGE ONLY THIS PATH
MYAPP_DIR = r"C:\Users\Udhaya\Downloads\PDFProcess"
# ------------------------------------

UPLOADS_DIR = os.path.join(MYAPP_DIR, "uploads")
INPROGRESS_DIR = os.path.join(UPLOADS_DIR, "inprogress")
PROCESSED_DIR = os.path.join(UPLOADS_DIR, "processed")
OUT_DIR = os.path.join(UPLOADS_DIR, "out")

# Create folders
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(INPROGRESS_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

# Pick one PDF file from uploads
pdf_files = [
    f for f in os.listdir(UPLOADS_DIR)
    if f.lower().endswith(".pdf") and os.path.isfile(os.path.join(UPLOADS_DIR, f))
]

if not pdf_files:
    print("No PDF found in uploads folder.")
    exit()

filename = pdf_files[0]
source_path = os.path.join(UPLOADS_DIR, filename)
inprogress_file = os.path.join(INPROGRESS_DIR, filename)

# 1. Move PDF → inprogress
print(f"➡ Moving to inprogress: {filename}")
shutil.move(source_path, inprogress_file)

# 2. Extract text
print(f"➡ Extracting text from {filename}")
pdf = fitz.open(inprogress_file)
extracted_text = ""
for page in pdf:
    extracted_text += page.get_text()
pdf.close()

# 3. Save TXT to OUT folder
txt_name = filename.replace(".pdf", ".txt")
txt_path = os.path.join(OUT_DIR, txt_name)

with open(txt_path, "w", encoding="utf-8") as t:
    t.write(extracted_text)

print(f"✔ Text saved in OUT folder as: {txt_name}")

# 4. Move PDF → processed
processed_pdf_path = os.path.join(PROCESSED_DIR, filename)
shutil.move(inprogress_file, processed_pdf_path)

print("✔ PDF moved to processed")
print("🎉 Completed successfully!")
