import fitz  # PyMuPDF
import os
import shutil

# ------------------------------------
# YOU ONLY CHANGE THIS PATH
MYAPP_DIR = r"C:\Users\Udhaya\Downloads\PDFProcess"
# ------------------------------------

# Auto-create folders
UPLOADS_DIR = os.path.join(MYAPP_DIR, "uploads")
PROCESSED_DIR = os.path.join(UPLOADS_DIR, "processed")
OUTPUT_TEXT_FILE = os.path.join(UPLOADS_DIR, "extracted.txt")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)

# Process all PDFs inside uploads folder
for filename in os.listdir(UPLOADS_DIR):
    if filename.lower().endswith(".pdf"):
        pdf_path = os.path.join(UPLOADS_DIR, filename)

        print(f"Processing: {filename}")

        # Extract text from PDF
        pdf = fitz.open(pdf_path)
        text = ""
        for page in pdf:
            text += page.get_text()
        pdf.close()

        # Append text to extracted.txt
        with open(OUTPUT_TEXT_FILE, "a", encoding="utf-8") as f:
            f.write(f"\n\n--- Extracted From: {filename} ---\n")
            f.write(text)

        # Move PDF to processed folder
        shutil.move(pdf_path, os.path.join(PROCESSED_DIR, filename))

print("✔ Done! All PDFs processed successfully.")
