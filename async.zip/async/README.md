Django File Scheduler
=====================

This project provides admin-driven file/folder scheduling using django-q.
See the admin to create ScheduledJob entries and manage them.

Steps:
1. create virtualenv, install requirements.txt
2. copy .env.example to .env and configure
3. python manage.py migrate
4. python manage.py createsuperuser
5. python manage.py runserver
6. python manage.py qcluster (dev) and python manage.py watch_folders (for folder triggers)
