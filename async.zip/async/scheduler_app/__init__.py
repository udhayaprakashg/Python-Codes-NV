default_app_config = 'scheduler_app.apps.SchedulerAppConfig'
