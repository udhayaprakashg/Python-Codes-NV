# scheduler_app/models.py
import uuid
from pathlib import Path
from django.db import models
from django.utils import timezone
from django.conf import settings


# 1. VirtualEnv
class VirtualEnv(models.Model):
    name = models.CharField(max_length=200, unique=True)
    path = models.CharField(
        max_length=1024,
        help_text="Full path to the virtual environment folder (e.g. C:\\venvs\\myenv)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Virtual Environment"
        verbose_name_plural = "Virtual Environments"
        ordering = ['-created_at']


# 2. Deployment
class Deployment(models.Model):
    custom_name = models.CharField(max_length=200, unique=True)
    unique_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.custom_name

    class Meta:
        ordering = ["-created_at"]


# 3. DeploymentVersion
class DeploymentVersion(models.Model):
    deployment = models.ForeignKey(
        Deployment, on_delete=models.CASCADE, related_name="versions"
    )
    version_number = models.PositiveIntegerField(null=True, blank=True)
    zip_file = models.FileField(upload_to="deployment_zips/")
    extracted_path = models.CharField(max_length=1024, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    # REQUIRED: ForeignKey to VirtualEnv
    virtual_env = models.ForeignKey(
        VirtualEnv, on_delete=models.PROTECT, related_name="versions"
    )

    class Meta:
        unique_together = ("deployment", "version_number")
        ordering = ["-version_number"]

    def __str__(self):
        return f"{self.deployment.custom_name} – v{self.version_number or '?'}"

    def save(self, *args, **kwargs):
        if self.pk is None and self.version_number is None:
            last = (
                DeploymentVersion.objects.filter(deployment=self.deployment)
                .order_by("-version_number")
                .first()
            )
            self.version_number = (last.version_number + 1) if last else 1
        super().save(*args, **kwargs)

# 5. ScheduledJob
class ScheduledJob(models.Model):
    name = models.CharField(max_length=200)
    enabled = models.BooleanField(default=True)

    TRIGGER_CHOICES = [
        ("folder", "Folder Watch"),
        ("once", "Run Once"),
        ("minutes", "Every N minutes"),
        ("hourly", "Hourly"),
        ("daily", "Daily"),
        ("weekly", "Weekly"),
        ("monthly", "Monthly"),
        ("yearly", "Yearly"),
        ("cron", "Cron Expression"),
    ]
    trigger_type = models.CharField(
        max_length=20, choices=TRIGGER_CHOICES, default="folder"
    )

    watch_path = models.CharField(max_length=1024, blank=True, null=True)
    file_pattern = models.CharField(max_length=200, blank=True, null=True)
    cron = models.CharField(max_length=200, blank=True, null=True)
    minutes_interval = models.PositiveIntegerField(blank=True, null=True)
    run_at = models.DateTimeField(blank=True, null=True)

    deployment_version = models.ForeignKey(
        DeploymentVersion,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="jobs",
    )
    db_alias = models.CharField(max_length=50, blank=True, null=True)

    q_schedule_id = models.BigIntegerField(blank=True, null=True, editable=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_run = models.DateTimeField(blank=True, null=True)
    last_status = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.name

    def active_path(self):
        return self.deployment_version.extracted_path if self.deployment_version else None

    def get_db_alias(self):
        alias = self.db_alias or "default"
        return alias if alias in settings.DATABASES else "default"

    # === ADD THIS METHOD INSIDE ScheduledJob class ===
    def next_run(self):
        if self.trigger_type == "folder":
            return "watching folder"
        if self.q_schedule_id:
            try:
                from django_q.models import Schedule
                sched = Schedule.objects.get(id=self.q_schedule_id)
                if sched.next_run:
                    return sched.next_run.astimezone(timezone.get_current_timezone())
            except Schedule.DoesNotExist:
                pass
        return "—"
    next_run.short_description = "Next run"
    next_run.admin_order_field = "q_schedule__next_run"

# 6. JobLog
class JobLog(models.Model):
    job = models.ForeignKey(
        ScheduledJob, on_delete=models.CASCADE, related_name="logs"
    )
    deployment_version = models.ForeignKey(
        DeploymentVersion, on_delete=models.SET_NULL, null=True, blank=True
    )
    started_at = models.DateTimeField(default=timezone.now)
    finished_at = models.DateTimeField(blank=True, null=True)
    success = models.BooleanField(default=False)
    message = models.TextField(blank=True)

    def __str__(self):
        return f"Log {self.job.name} @ {self.started_at.isoformat()}"
    
    