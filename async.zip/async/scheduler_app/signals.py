# scheduler_app/signals.py
import json
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.utils import timezone
from django_q.models import Schedule

from .models import ScheduledJob


@receiver(post_save, sender=ScheduledJob)
def manage_schedule(sender, instance, created, **kwargs):
    job = instance

    # 1. Clean old schedule
    if job.q_schedule_id:
        Schedule.objects.filter(id=job.q_schedule_id).delete()
        # Use .update() → NO SIGNAL → NO RECURSION
        ScheduledJob.objects.filter(pk=job.pk).update(q_schedule_id=None)

    if not job.enabled:
        return

    # 2. SKIP folder jobs - they're handled by watch_folders.py command
    if job.trigger_type == "folder":
        print(f"ℹ️  Job '{job.name}' is folder-watch type → managed by watch_folders.py command")
        return

    # 3. Create new Django-Q schedule for non-folder jobs
    kwargs_json = json.dumps({"job_id": job.id})

    def create(**kw):
        s = Schedule.objects.create(
            name=f"{job.name} – {job.trigger_type}",
            func="scheduler_app.tasks.execute_job",
            kwargs=kwargs_json,
            **kw,
        )
        # Use .update() → NO SIGNAL → NO RECURSION
        ScheduledJob.objects.filter(pk=job.pk).update(q_schedule_id=s.id)

    if job.trigger_type == "cron" and job.cron:
        create(cron=job.cron, next_run=timezone.now())
    elif job.trigger_type == "once" and job.run_at:
        create(schedule_type=Schedule.ONCE, next_run=job.run_at)
    elif job.trigger_type == "minutes" and job.minutes_interval:
        create(schedule_type=Schedule.MINUTES, minutes=job.minutes_interval, next_run=timezone.now())
    elif job.trigger_type == "hourly":
        create(schedule_type=Schedule.HOURLY, next_run=timezone.now())
    elif job.trigger_type == "daily":
        create(schedule_type=Schedule.DAILY, next_run=timezone.now())
    elif job.trigger_type == "weekly":
        create(schedule_type=Schedule.WEEKLY, next_run=timezone.now())
    elif job.trigger_type == "monthly":
        create(schedule_type=Schedule.MONTHLY, next_run=timezone.now())
    elif job.trigger_type == "yearly":
        create(schedule_type=Schedule.YEARLY, next_run=timezone.now())


@receiver(pre_delete, sender=ScheduledJob)
def cleanup_on_delete(sender, instance, **kwargs):
    if instance.q_schedule_id:
        Schedule.objects.filter(id=instance.q_schedule_id).delete()