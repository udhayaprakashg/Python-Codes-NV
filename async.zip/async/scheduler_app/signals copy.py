# scheduler_app/signals.py
import json
from pathlib import Path
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.utils import timezone
from django_q.models import Schedule
from watchdog.observers import Observer

from .models import ScheduledJob

_observers = {}


def _start_folder_observer(job):
    if not job.watch_path or not Path(job.watch_path).exists():
        print(f"Warning: Job '{job.name}' - Invalid watch path: {job.watch_path}")
        return

    from watchdog.events import FileSystemEventHandler
    from django_q.tasks import async_task

    class Handler(FileSystemEventHandler):
        def on_created(self, event):
            if not event.is_directory:
                print(f"File detected: {event.src_path} → Triggering job '{job.name}'")
                async_task("scheduler_app.tasks.execute_job", job.id)

    observer = Observer()
    observer.schedule(Handler(), job.watch_path, recursive=False)
    observer.start()
    _observers[job.id] = observer


def _stop_folder_observer(job_id):
    obs = _observers.pop(job_id, None)
    if obs:
        obs.stop()
        obs.join()


@receiver(post_save, sender=ScheduledJob)
def manage_schedule(sender, instance, created, **kwargs):
    job = instance

    # 1. Clean old schedule
    if job.q_schedule_id:
        Schedule.objects.filter(id=job.q_schedule_id).delete()
        # FIX: Use .update() → NO SIGNAL → NO RECURSION
        ScheduledJob.objects.filter(pk=job.pk).update(q_schedule_id=None)

    if not job.enabled:
        _stop_folder_observer(job.id)
        return

    if job.trigger_type == "folder":
        _stop_folder_observer(job.id)
        _start_folder_observer(job)
        return

    # 2. Create new Django-Q schedule
    kwargs_json = json.dumps({"job_id": job.id})

    def create(**kw):
        s = Schedule.objects.create(
            name=f"{job.name} – {job.trigger_type}",
            func="scheduler_app.tasks.execute_job",
            kwargs=kwargs_json,
            **kw,
        )
        # FIX: Use .update() → NO SIGNAL → NO RECURSION
        ScheduledJob.objects.filter(pk=job.pk).update(q_schedule_id=s.id)

    if job.trigger_type == "cron" and job.cron:
        create(cron=job.cron, next_run=timezone.now())
    elif job.trigger_type == "once" and job.run_at:
        create(schedule_type=Schedule.ONCE, next_run=job.run_at)
    elif job.trigger_type == "minutes" and job.minutes_interval:
        create(schedule_type=Schedule.MINUTES, minutes=job.minutes_interval, next_run=timezone.now())
    elif job.trigger_type == "hourly":
        create(schedule_type=Schedule.HOURLY, next_run=timezone.now())
    elif job.trigger_type == "daily":
        create(schedule_type=Schedule.DAILY, next_run=timezone.now())
    elif job.trigger_type == "weekly":
        create(schedule_type=Schedule.WEEKLY, next_run=timezone.now())
    elif job.trigger_type == "monthly":
        create(schedule_type=Schedule.MONTHLY, next_run=timezone.now())
    elif job.trigger_type == "yearly":
        create(schedule_type=Schedule.YEARLY, next_run=timezone.now())


@receiver(pre_delete, sender=ScheduledJob)
def cleanup_on_delete(sender, instance, **kwargs):
    _stop_folder_observer(instance.id)
    if instance.q_schedule_id:
        Schedule.objects.filter(id=instance.q_schedule_id).delete()