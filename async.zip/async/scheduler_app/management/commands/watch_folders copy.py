# scheduler_app/management/commands/watch_folders.py
import signal
import sys
import threading
from pathlib import Path
from django.core.management.base import BaseCommand
from django.utils import timezone
from scheduler_app.models import ScheduledJob
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from django_q.tasks import async_task


# Global list to keep observers alive
_observers = []
_shutdown_event = threading.Event()


class NewFileHandler(FileSystemEventHandler):
    def __init__(self, job_id, job_name):
        self.job_id = job_id
        self.job_name = job_name

    def on_created(self, event):
        if event.is_directory:
            return
        print(f"[{timezone.now().strftime('%H:%M:%S')}] File: {event.src_path} → Trigger: {self.job_name}")
        # This runs in its own thread → safe + non-blocking
        async_task('scheduler_app.tasks.execute_job', self.job_id)


def start_observer_for_job(job, stop_event):
    """Run one observer per job in its own thread"""
    if not job.watch_path or not Path(job.watch_path).exists():
        print(f"Warning: Invalid path for job '{job.name}': {job.watch_path}")
        return

    observer = Observer()
    handler = NewFileHandler(job.id, job.name)
    observer.schedule(handler, job.watch_path, recursive=False)

    print(f"Started watching: {job.watch_path} → {job.name}")

    observer.start()
    _observers.append(observer)

    try:
        while not stop_event.is_set():
            stop_event.wait(1)  # 1-second poll
    except KeyboardInterrupt:
        pass
    finally:
        observer.stop()
        observer.join()
        print(f"Stopped watching: {job.name}")


class Command(BaseCommand):
    help = 'Watch multiple folders in parallel (one thread per folder)'

    def handle(self, *args, **options):
        global _observers
        _observers.clear()

        jobs = ScheduledJob.objects.filter(enabled=True, trigger_type='folder')
        valid_jobs = [j for j in jobs if j.watch_path and Path(j.watch_path).exists()]


        if not valid_jobs:
            self.stdout.write(self.style.WARNING('No valid folder-watch jobs to monitor.'))
            return

        self.stdout.write(self.style.SUCCESS(f'Starting {len(valid_jobs)} parallel folder watchers...'))

        # Start one thread per job
        threads = []
        for job in valid_jobs:
            t = threading.Thread(
                target=start_observer_for_job,
                args=(job, _shutdown_event),
                daemon=True
            )
            t.start()
            threads.append(t)

        # Graceful shutdown on Ctrl+C
        def signal_handler(sig, frame):
            self.stdout.write(self.style.WARNING('\nShutting down folder watchers...'))
            _shutdown_event.set()

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

        self.stdout.write(self.style.SUCCESS(
            f'Watching {len(valid_jobs)} folder(s) in parallel. Press Ctrl+C to stop.\n'
        ))

        try:
            # Keep main thread alive
            while not _shutdown_event.is_set() and any(t.is_alive() for t in threads):
                _shutdown_event.wait(1)
        except KeyboardInterrupt:
            pass
        finally:
            _shutdown_event.set()
            for t in threads:
                t.join(timeout=2)
            self.stdout.write(self.style.SUCCESS('All folder watchers stopped.'))