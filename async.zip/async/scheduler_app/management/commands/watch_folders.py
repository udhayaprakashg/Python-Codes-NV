# scheduler_app/management/commands/watch_folders.py
import signal
import os
import sys
import time
import threading
from pathlib import Path
from django.core.management.base import BaseCommand
from django.utils import timezone
from scheduler_app.models import ScheduledJob
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from django_q.tasks import async_task

LOCK_FILE = "watch_folders.lock"
_batch = {}      # {job_id: set(file_paths)}
_timers = {}     # {job_id: Timer}
_lock = threading.Lock()
DEBOUNCE = 2     # seconds


def _trigger_batch(job_id):
    with _lock:
        files = list(_batch.pop(job_id, set()))
        timer = _timers.pop(job_id, None)
        if timer:
            timer.cancel()

    if not files:
        print(f"[SKIP] Empty batch for job {job_id} (no real files)")
        return  # IMPORTANT: prevent sending empty list to task

    print(f"\nBATCH TRIGGER → Job {job_id} | {len(files)} file(s)")
    for f in files:
        print(f"  → {Path(f).name}")

    async_task(
        'scheduler_app.tasks.execute_job',
        job_id,
        file_paths=files,
        filepath_trigger='Yes',
        using=ScheduledJob.objects.using('default').get(pk=job_id).get_db_alias()
    )


def _schedule_debounce(job_id):
    with _lock:
        old_timer = _timers.get(job_id)
        if old_timer:
            old_timer.cancel()

        timer = threading.Timer(DEBOUNCE, _trigger_batch, args=(job_id,))
        timer.daemon = True
        timer.start()
        _timers[job_id] = timer


class BatchFileHandler(FileSystemEventHandler):
    def __init__(self, job):
        self.job = job

    def on_created(self, event):
        if event.is_directory:
            return
        file_path = event.src_path
        file_path = str(Path(file_path).resolve())

        with _lock:
            batch = _batch.setdefault(self.job.id, set())
            if file_path not in batch:
                batch.add(file_path)
                print(f"[{timezone.now().strftime('%H:%M:%S')}] + {Path(file_path).name}")

        _schedule_debounce(self.job.id)


class Command(BaseCommand):
    help = 'Watch folders → batch files → 1 job'

    def handle(self, *args, **options):
        global _batch, _timers
        if os.path.exists(LOCK_FILE):
            self.stdout.write(self.style.ERROR("Another instance running."))
            sys.exit(1)

        with open(LOCK_FILE, 'w') as f:
            f.write(str(os.getpid()))

        def cleanup(*_):
            if os.path.exists(LOCK_FILE):
                os.remove(LOCK_FILE)
            for obs in observers:
                obs.stop()
            with _lock:
                for t in _timers.values():
                    t.cancel()
            self.stdout.write(self.style.SUCCESS("\nStopped."))

        signal.signal(signal.SIGINT, cleanup)
        signal.signal(signal.SIGTERM, cleanup)

        observers = []
        try:
            for job in ScheduledJob.objects.filter(enabled=True, trigger_type='folder'):
                path = job.watch_path
                if not path or not os.path.exists(path):
                    self.stdout.write(self.style.WARNING(f"Invalid path: {path}"))
                    continue

                observer = Observer()
                handler = BatchFileHandler(job)
                observer.schedule(handler, path, recursive=False)
                observer.start()
                observers.append(observer)
                self.stdout.write(self.style.SUCCESS(f'Watching: {path} → {job.name} (batched)'))

            if not observers:
                self.stdout.write(self.style.WARNING('No folders to watch.'))
                cleanup()
                return

            self.stdout.write(self.style.SUCCESS(f'\nWatching {len(observers)} folder(s) → 1 job per batch (2 sec)\n'))
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nCTRL+C detected → stopping watchers...")

        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error: {e}"))
        finally:
            cleanup()
            for obs in observers:
                obs.join()