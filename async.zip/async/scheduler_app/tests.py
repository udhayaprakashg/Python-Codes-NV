from django.test import TestCase

class SimpleTest(TestCase):
    def test_import(self):
        import scheduler_app
        self.assertTrue(True)
